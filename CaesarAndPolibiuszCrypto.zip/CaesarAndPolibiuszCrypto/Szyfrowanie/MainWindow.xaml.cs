﻿using Caesar.Windows;
using Polibiusz.Windows;
using PolibiuszKeyTransposition.Windows;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Szyfrowanie
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Caesar_Click(object sender, RoutedEventArgs e)
        {
            CaesarWindow caesarWindow = new CaesarWindow();
            caesarWindow.Show();
        }

        private void Polibiusz_Click(object sender, RoutedEventArgs e)
        {
            PolibiuszWindow polibiuszWindow = new PolibiuszWindow();
            polibiuszWindow.Show();
        }

        private void Polibiusz_With_Transposition_Click(object sender, RoutedEventArgs e)
        {
            PolibiuszWithTranspositionWindow polibiuszWindow = new PolibiuszWithTranspositionWindow();
            polibiuszWindow.Show();
        }
    }
}