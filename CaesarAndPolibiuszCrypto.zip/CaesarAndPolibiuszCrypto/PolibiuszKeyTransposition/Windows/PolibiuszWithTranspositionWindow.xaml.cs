﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PolibiuszKeyTransposition.Windows
{
    /// <summary>
    /// Interaction logic for PolibiuszWithTranspositionWindow.xaml
    /// </summary>
    public partial class PolibiuszWithTranspositionWindow : Window
    {
        private TextBox[,] cipherGrid = new TextBox[7, 7];

        public PolibiuszWithTranspositionWindow()
        {
            InitializeComponent();
            InitializeCipherGrid();
        }

        private void InitializeCipherGrid()
        {
            Grid cipherTable = (Grid)this.FindName("CipherGrid");
            for (int row = 0; row < 5; row++)
            {
                for (int col = 0; col < 7; col++)
                {
                    TextBox textBox = new TextBox
                    {
                        Margin = new Thickness(2),
                        VerticalAlignment = VerticalAlignment.Center,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        Width = 35,
                        Height = 35,
                        MaxLength = 1,
                        TextAlignment = TextAlignment.Center
                    };
                    Grid.SetRow(textBox, row);
                    Grid.SetColumn(textBox, col);
                    cipherGrid[row, col] = textBox;
                    cipherTable.Children.Add(textBox);
                }
            }
        }

        private TextBox[,] TransposeCipherGrid(string key)
        {
            int[] keyArray = key.Select(x => int.Parse(x.ToString())).ToArray();

            TextBox[,] transposedCipherGrid = new TextBox[5, 7];

            for (int row = 0; row < 5; row++)
            {
                for (int col = 0; col < 7; col++)
                {
                    int newCol = Array.IndexOf(keyArray, col + 1);
                    transposedCipherGrid[row, newCol] = cipherGrid[row, col];
                }
            }

            return transposedCipherGrid;
        }


        private bool IsValidKey(string key)
        {
            var numbers = key.Select(n => int.TryParse(n.ToString(), out int x) ? x : -1).ToList();
            return numbers.Count == 7 && numbers.Distinct().Count() == 7 && numbers.All(n => n >= 1 && n <= 7);
        }

        private void EncryptButton_Click(object sender, RoutedEventArgs e)
        {
            string inputText = InputTextBox.Text;

            string key = KeyTextBox.Text;
            if (IsValidKey(key))
            {
                var transposedGrid = TransposeCipherGrid(key);
                string encryptedText = Encrypt(inputText, transposedGrid);
                OutputTextBox.Text = encryptedText;
            }
            else
            {
                MessageBox.Show("Nieprawidłowy klucz. Klucz musi zawierać 7 unikalnych liczb od 1 do 7.");
            }
        }

        private void DecryptButton_Click(object sender, RoutedEventArgs e)
        {
            string encryptedText = InputTextBox.Text;

            string key = KeyTextBox.Text;
            if (IsValidKey(key))
            {
                var transposedGrid = TransposeCipherGrid(key);
                string decryptedText = Decrypt(encryptedText, transposedGrid);
                OutputTextBox.Text = decryptedText;
            }
            else
            {
                MessageBox.Show("Nieprawidłowy klucz. Klucz musi zawierać 7 unikalnych liczb od 1 do 7.");
            }            
        }

        private string Encrypt(string input, TextBox[,] grid)
        {
            var encryptedText = new StringBuilder();

            input = input.ToUpper();

            foreach (char character in input)
            {
                for (int row = 0; row < 5; row++)
                {
                    for (int col = 0; col < 7; col++)
                    {
                        if (grid[row, col].Text.ToUpper() == character.ToString())
                        {
                            encryptedText.Append($"{row + 1}{col + 1} ");
                            break;
                        }
                    }
                }
            }

            return encryptedText.ToString().Trim();
        }

        private string Decrypt(string input, TextBox[,] grid)
        {
            var decryptedText = new StringBuilder();

            var pairs = input.Split(' ');

            foreach (var pair in pairs)
            {
                if (pair.Length == 2 && int.TryParse(pair, out int position))
                {
                    int row = (position / 10) - 1;
                    int col = (position % 10) - 1;

                    if (row >= 0 && row < 5 && col >= 0 && col < 7)
                    {
                        decryptedText.Append(grid[row, col].Text);
                    }
                }
            }

            return decryptedText.ToString();
        }
    }
}
