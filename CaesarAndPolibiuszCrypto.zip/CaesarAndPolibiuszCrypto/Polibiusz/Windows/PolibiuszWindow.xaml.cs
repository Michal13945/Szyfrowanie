﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Polibiusz.Windows
{
    /// <summary>
    /// Interaction logic for PolibiuszWindow.xaml
    /// </summary>
    public partial class PolibiuszWindow : Window
    {
        private TextBox[,] cipherGrid = new TextBox[7, 7];

        public PolibiuszWindow()
        {
            InitializeComponent();
            InitializeCipherGrid();
        }

        private void InitializeCipherGrid()
        {
            Grid cipherTable = (Grid)this.FindName("CipherGrid");
            for (int row = 0; row < 5; row++)
            {
                for (int col = 0; col < 7; col++)
                {
                    TextBox textBox = new TextBox
                    {
                        Margin = new Thickness(2),
                        VerticalAlignment = VerticalAlignment.Center,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        Width = 35,
                        Height = 35,
                        MaxLength = 1,
                        TextAlignment = TextAlignment.Center
                    };
                    Grid.SetRow(textBox, row);
                    Grid.SetColumn(textBox, col);
                    cipherGrid[row, col] = textBox;
                    cipherTable.Children.Add(textBox);
                }
            }
        }

        private void EncryptButton_Click(object sender, RoutedEventArgs e)
        {
            string inputText = InputTextBox.Text;
            string encryptedText = Encrypt(inputText);
            OutputTextBox.Text = encryptedText;
        }

        private void DecryptButton_Click(object sender, RoutedEventArgs e)
        {
            string encryptedText = InputTextBox.Text;
            string decryptedText = Decrypt(encryptedText);
            OutputTextBox.Text = decryptedText;
        }

        private string Encrypt(string input)
        {
            var encryptedText = new StringBuilder();

            input = input.ToUpper();

            foreach (char character in input)
            {
                for (int row = 0; row < 5; row++)
                {
                    for (int col = 0; col < 7; col++)
                    {
                        if (cipherGrid[row, col].Text.ToUpper() == character.ToString())
                        {
                            encryptedText.Append($"{row + 1}{col + 1} ");
                            break;
                        }
                    }
                }
            }

            return encryptedText.ToString().Trim();
        }

        private string Decrypt(string input)
        {
            var decryptedText = new StringBuilder();

            var pairs = input.Split(' ');

            foreach (var pair in pairs)
            {
                if (pair.Length == 2 && int.TryParse(pair, out int position))
                {
                    int row = (position / 10) - 1;
                    int col = (position % 10) - 1;

                    if (row >= 0 && row < 5 && col >= 0 && col < 7)
                    {
                        decryptedText.Append(cipherGrid[row, col].Text);
                    }
                }
            }

            return decryptedText.ToString();
        }
    }
}
