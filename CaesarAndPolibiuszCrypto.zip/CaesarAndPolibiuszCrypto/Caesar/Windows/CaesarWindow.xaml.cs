﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Caesar.Windows
{
    /// <summary>
    /// Interaction logic for CaesarWindow.xaml
    /// </summary>
    public partial class CaesarWindow : Window
    {
        public CaesarWindow()
        {
            InitializeComponent();
        }

        private void EncryptButton_Click(object sender, RoutedEventArgs e)
        {
            ProcessInput(true);
        }

        private void DecryptButton_Click(object sender, RoutedEventArgs e)
        {
            ProcessInput(false);
        }

        private void ProcessInput(bool isEncrypting)
        {
            var inputText = InputTextBox.Text;
            var selectedRadioButton = GetSelectedRadioButton();

            if (selectedRadioButton != null)
            {
                if (isEncrypting)
                {
                    OutputTextBox.Text = CaesarCipher(inputText, (int)selectedRadioButton);
                }
                else
                {
                    OutputTextBox.Text = CaesarDecipher(inputText, (int)selectedRadioButton);
                }
            }
        }

        private int? GetSelectedRadioButton()
        {
            foreach (UIElement element in RadiosWrapPanel.Children)
            {
                if (element is RadioButton radioButton && radioButton.IsChecked == true)
                {
                    return int.Parse(radioButton.Content.ToString());
                }
            }

            return null; 
        }

        private string CaesarCipher(string input, int shift)
        {
            char[] characters = input.ToCharArray();
            for (int i = 0; i < characters.Length; i++)
            {
                char character = characters[i];
                if (char.IsLetter(character))
                {
                    char offset = char.IsUpper(character) ? 'A' : 'a';
                    character = (char)((character + shift - offset) % 26 + offset);
                }
                characters[i] = character;
            }
            return new string(characters);
        }

        private string CaesarDecipher(string input, int shift)
        {
            char[] characters = input.ToCharArray();
            for (int i = 0; i < characters.Length; i++)
            {
                char character = characters[i];
                if (char.IsLetter(character))
                {
                    char offset = char.IsUpper(character) ? 'A' : 'a';
                    character = (char)((character - shift - offset) % 26 + offset);
                }
                characters[i] = character;
            }
            return new string(characters);
        }
    }
}
